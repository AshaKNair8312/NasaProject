package com.example.nasa.views.splash

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.example.nasa.R
import com.example.nasa.utils.Constants
import com.example.nasa.views.home.HomeActivity
import com.example.nasa.views.home.HomeAdapter
import timber.log.Timber

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        setupDelay()
    }

    private fun setupDelay() {
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }, Constants.SPLASH_TIME_OUT)
    }
}
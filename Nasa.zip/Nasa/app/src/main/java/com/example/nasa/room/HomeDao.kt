package com.example.nasa.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.nasa.dataprovider.HomeData

@Dao
interface HomeDao {
    @Query("SELECT * FROM HomeData")
    fun getAll(): List<HomeData>

    @Insert
    fun insertAll(vararg home:HomeData)

}
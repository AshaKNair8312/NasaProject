package com.example.nasa.views.home

import android.annotation.SuppressLint
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.*
import com.example.nasa.dataprovider.HomeData
import com.example.nasa.dataprovider.HomeResponse
import com.example.nasa.network.APIService
import com.example.nasa.network.PostDataSource
import kotlinx.coroutines.flow.Flow
import timber.log.Timber

class HomeViewModel(@SuppressLint("StaticFieldLeak") private val appContext: Context, private val apiService: APIService) : ViewModel() {

    var showProgress = MutableLiveData<Boolean>()

    init {
        showProgress.value = true

    }

    val listData = Pager(PagingConfig(pageSize = 10)) {
        PostDataSource(appContext,apiService)
    }.flow.cachedIn(viewModelScope)


    fun setProgress(b: Boolean) {
        showProgress.value = b
    }


}
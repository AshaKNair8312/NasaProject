package com.example.nasa.network

import android.content.Context
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.room.Room
import com.example.nasa.dataprovider.HomeData
import com.example.nasa.room.AppDatabase
import com.example.nasa.utils.Constants
import timber.log.Timber

class PostDataSource(
    private val appContext: Context, private val apiService: APIService
    ) :
    PagingSource<Int, HomeData>() {

    val db = Room.databaseBuilder(
        appContext,
        AppDatabase::class.java, "NasaDB16"
    ).allowMainThreadQueries()
        .build()
    val homeDao = db.homeDao()

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, HomeData> {
        try {
            val currentLoadingPageKey = params.key ?: 10
            val response = apiService.getListAsync(Constants.API_KEY, currentLoadingPageKey)
            Timber.d("loadeingresponse $response")
            val responseData = mutableListOf<HomeData>()
            val data = response.body() ?: emptyList()

            data.forEach {
                val homeData = HomeData(
                    0,
                    it.copyright,
                    it.date,
                    it.explanation, it.hdurl, it.media_type, it.service_version, it.title, it.url
                )
                responseData.add(homeData)
                homeDao.insertAll(homeData)
            }

            val prevKey = if (currentLoadingPageKey == 10) null else currentLoadingPageKey - 10

            return LoadResult.Page(
                data = responseData,
                prevKey = prevKey,
                nextKey = currentLoadingPageKey.plus(10)
            )

        } catch (e: Exception) {
            Timber.d("loadeingresponseError ${e.message}")
            return LoadResult.Error(e)
        }
    }


    override fun getRefreshKey(state: PagingState<Int, HomeData>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            val anchorPage = state.closestPageToPosition(anchorPosition)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }


}
package com.example.nasa.views.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.nasa.network.APIService

class HomeViewModelFactory(private val context: Context, private val apiService: APIService) : ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            return HomeViewModel(context,apiService) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
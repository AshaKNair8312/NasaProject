package com.example.nasa.views.home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingData
import androidx.room.Room
import com.example.nasa.R
import com.example.nasa.databinding.ActivityHomeBinding
import com.example.nasa.network.APIService
import com.example.nasa.room.AppDatabase
import com.example.nasa.room.HomeDao
import com.example.nasa.utils.isInternetAvailable
import com.example.nasa.views.details.DetailActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private lateinit var viewModel: HomeViewModel
    private lateinit var homeAdapter: HomeAdapter
    private lateinit var homeDao: HomeDao

    @InternalCoroutinesApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupBinding()
        setupList()
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "NasaDB16"
        ).allowMainThreadQueries().build()
        homeDao = db.homeDao()
        setupView()
    }

    @InternalCoroutinesApi
    private fun setupView() {

        lifecycleScope.launch {
            viewModel.listData.collectLatest { pagingData ->
                val dataFromDb = homeDao.getAll()
                if (!isInternetAvailable()) {
                    viewModel.setProgress(false)
                    homeAdapter.submitData(PagingData.from(dataFromDb))
                } else {
                    viewModel.setProgress(false)
                    homeAdapter.submitData(pagingData)
                }
            }
        }
    }

    private fun setupList() {
        homeAdapter = HomeAdapter(HomeClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("detailData", it)
            startActivity(intent)
        })
        binding.homeRecycler.adapter = homeAdapter
    }

    private fun setupBinding() {
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home)
        viewModel =
            ViewModelProvider(
                this,
                HomeViewModelFactory(this, APIService.getApiService())
            )[HomeViewModel::class.java]
        binding.viewModel = viewModel
        binding.lifecycleOwner = this
    }

}